# Aerospace student portfolio

A responsive, static portfolio designed for GitHub Pages. No build tools are required.

## Personalize it

Open `index.html` and replace these placeholders:

- `Your Name` (including the short `YN` brand mark)
- `your.email@example.com`
- `linkedin.com/in/your-profile`
- `github.com/your-username`
- Create an `images` folder and add his image as `profile.jpg`. (If using a different filename or type, update `images/profile.jpg` in `index.html`.)

The text intentionally represents an early-stage aerospace student and does not claim projects, awards, internships, or experience that have not happened yet.

## Publish with GitHub Pages

1. Create a GitHub repository and upload these four files to its top level.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, then select `main` and `/ (root)`.
4. Save. GitHub will provide the public site address shortly afterward.
